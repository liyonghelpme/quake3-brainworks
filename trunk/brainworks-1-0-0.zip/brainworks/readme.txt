Brainworks v1.0.0 Beta
http://brainworks-ai.blogspot.com
tedvessenes@gmail.com
Irc Channel #artofwar @ irc.gamesurge.net


INTRODUCTION
------------

This is a beta version of the brainworks Q3A mod, the mod designed to
give Quake 3 Arena bots working brains.  It is a complete rewrite of
all the Artificial Intelligence used by the bots.  Brainworks includes:

- Sound and visual awareness system
- Randomized dodging in battles
- Avoidance of incoming missiles
- Strafejumping
- Improved enemy aiming (based on human compensation model)
- Goal and score-based selection of item pickups
- Timing of item respawns
- Dynamic weapon selection (based on weapon accuracy)
- Redesigned internal goal selection
- Redesigned internal aim selection
- Redesigned Teamplay logic
- Rewritten chat code
- Redesigned internal logic infrastructure
- MANY MANY fixes for bugs in original Q3A bot code

Some features only apply to bots of a certain skill level.  For example,
skill 1 and 2 bots have access to almost none of those features, whereas
skill 5 bots use all of them.

The goal of Brainworks is to make Quake 3 Arena bots as human-like as
possible.  With that in mind, the following human equivalents were set
as the "goal for realism" for each bot.

Skill 1: Someone who has played Q3A for less than 2 weeks
Skill 2: Someone who has played Q3A for less than 3 months
Skill 3: Average player on a public server
Skill 4: The best player on a public server
Skill 5: A clan player who plays in professional tournaments

Obviously it's harder to make realistic skill 5 bots than skill 1 bots,
but we've done everything we can in a reasonable amount of time to
reach these five goals for realistic bots.


INSTALLATION
------------

To install Brainworks, extract the zip file from your "quake3" directory.
The "brainworks" directory should automatically be created as a subdirectory
of "quake3".  The brainworks directory will now contain the following files:

  - brainworks.pk3
  - description.txt
  - readme.txt

To run Brainworks, either launch quake3 and select Brainworks from the
"mods" menu tab, or load Brainworks directly with:

quake3 +set fs_game brainworks

You can confirm that brainworks is loaded by adding a bot.  If you see
the message "Successfully loaded Brainworks Bot", Brainworks is loaded.
If you don't see this message when adding a bot, you are still running
vanilla Quake 3 Arena.


KNOWN ISSUES
------------

Please email me (tedvessenes@gmail.com) if you find any bugs.